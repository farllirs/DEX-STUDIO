# {{APP_NAME}}

{{DESCRIPTION}}

## Autor
{{CREATOR}}

## Versión
{{VERSION}}

## Instalación
1. Copia esta carpeta a `modules/` en DEX STUDIO
2. Reinicia el editor
3. La extensión se cargará automáticamente

## Desarrollo
- Edita `main.js` para agregar funcionalidad
- Modifica `manifest.json` para cambiar metadatos
- Usa `DEX.registerExtension()` para registrar handlers
